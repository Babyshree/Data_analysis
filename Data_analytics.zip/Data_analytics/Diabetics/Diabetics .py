#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[4]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score


# In[7]:


data=pd.read_csv("diabetes.csv")


# In[8]:


data.head()


# In[9]:


sns.heatmap(data.isnull())


# In[10]:


correlation=data.corr()
correlation


# In[14]:


import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import seaborn as sns

# Assuming 'data' is your DataFrame and 'correlation' is the correlation matrix
correlation = data.corr()

# Create a custom colormap
cmap_colors = [(0, 0, 0), (0, 0.5, 0.5), (0.8, 0.8, 0.8)]  # Black to Teal to Light Gray
custom_cmap = LinearSegmentedColormap.from_list('custom', cmap_colors, N=256)

# Create a heatmap without annotations using the custom colormap
plt.figure(figsize=(10, 8))
sns.heatmap(correlation, cmap=custom_cmap, cbar=False)
plt.title('Correlation Matrix Heatmap')
plt.show()


# In[15]:


X=data.drop("Outcome",axis=1)
Y=data['Outcome']
X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.2)


# In[16]:


model=LogisticRegression()
model.fit(X_train,Y_train)


# In[18]:


prediction=model.predict(X_test)


# In[20]:


print(prediction)


# In[21]:


accuracy=accuracy_score(prediction,Y_test)


# In[22]:


print(accuracy)


# In[ ]:




